module.exports = (app) => {
    const affectations = require('../controllers/affectation.controller.js');


    app.post('/affectations', affectations.create);

    
    app.get('/affectations', affectations.findAll);

   
    app.get('/affectations/:affectationId', affectations.findOne);

    
    app.put('/affectations/:affectationsId', affectations.update);

    
    app.delete('/affectations/:affectationId', affectations.delete);
}
