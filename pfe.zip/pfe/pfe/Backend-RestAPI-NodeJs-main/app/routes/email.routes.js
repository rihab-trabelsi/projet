module.exports = (app) => {
    const messages = require('../controllers/email.controller.js');


    app.post('/emails', emails.create);

    
    app.get('/emails', emails.findAll);

   
    app.get('/emails/:emailId', emails.findOne);

    
    app.delete('/emails/:emailId', emails.delete);
}
