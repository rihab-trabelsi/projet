module.exports = (app) => {
    const prospects = require('../controllers/prospect.controller.js');


    app.post('/prospects', prospects.create);

    
    app.get('/prospects', prospects.findAll);

   
    app.get('/prospects/:prospectId', prospects.findOne);

    
    app.put('/prospects/:prospectId', prospects.update);

    
    app.delete('/prospects/:prospectId', prospects.delete);
}
