module.exports = (app) => {
    const taches = require('../controllers/tache.controller.js');


    app.post('/taches', taches.create);

    
    app.get('/taches', taches.findAll);

   
    app.get('/taches/:tacheId', taches.findOne);

    
    app.put('/taches/:tacheId', taches.update);

    
    app.delete('/taches/:tacheId', taches.delete);
}
