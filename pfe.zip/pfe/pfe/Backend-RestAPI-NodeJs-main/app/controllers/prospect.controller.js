const Tache = require('../models/prospect.model.js');

// Create and Save a new prospect
exports.create = (req, res) => {
    // Validate request
    if(!req.body.date) {
        return res.status(400).send({
            message: "prospect content can not be empty"
        });
    }

    // Create a prospect
    const prospect = new Prospect({
        nom_prospect: req.body.nom || "Untitled prospect", 
        nom_contact : req.body.nom_contact, 
        email : req.body.email,
        date: req.body.date,   
        lieu : req.body.ville, 
        volume_annuel : req.body.volume,
        heure_arrive :req.body.heure,
        type_client :req.body.type_client,
        nature_client :req.body.nature_client,
        decrir :req.body.decrir,
        autre :req.body.autre,
        cause :req.body.cause,
        resultat :req.body.resultat,
        commande :req.body.commande,
        frs :req.body.frs,
        prix :req.body.prix,
        remarque :req.body.remarque,

    });

    // Save prospect in the database
    prospect.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the prospect."
        });
    });
};

// Retrieve and return all prospect from the database.
exports.findAll = (req, res) => {
    Prospect.find()
    .then(prospects => {
        res.send(prospects);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving prospects."
        });
    });
};

// Find a single prospect with a prospectId
exports.findOne = (req, res) => {
    Prospect.findById(req.params.prospectId)
    .then(prospect => {
        if(!prospect) {
            return res.status(404).send({
                message: "prospect not found with id " + req.params.prospectId
            });            
        }
        res.send(prospect);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "prospect not found with id " + req.params.prospectId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving prospect with id " + req.params.prospectId
        });
    });
};

// Update a prospect identified by the prospectId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.date) {
        return res.status(400).send({
            message: "prospect content can not be empty"
        });
    }

    // Find prospect and update it with the request body
    Tache.findByIdAndUpdate(req.params.prospectId, {
        nom_prospect: req.body.nom_prospect || "Untitled prospect", 
        nom_contact : req.body.nom_contact, 
        email: req.body.email,
        date : req.body.date,
        lieu :req.body.lieu,
        volume_annuel :req.body.volume_annuel,
        heure_arrive :req.body.heure_arrive,
        type_client :req.body.type_client,
        nature_client :req.body.nature_client,
        decrir :req.body.decrir,
        autre :req.body.autre,
        cause :req.body.cause,
        resultat :req.body.resultat,
        commande :req.body.commande,
        frs :req.body.frs,
        prix :req.body.prix,
        remarque :req.body.remarque,



    }, {new: true})
    .then(prospect => {
        if(!prospect) {
            return res.status(404).send({
                message: "prospect not found with id " + req.params.prospectId
            });
        }
        res.send(prospect);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "prospect not found with id " + req.params.prospectId
            });                
        }
        return res.status(500).send({
            message: "Error updating prospect with id " + req.params.prospectId
        });
    });
};

// Delete a prospect with the specified adminId in the request
exports.delete = (req, res) => {
    Prospect.findByIdAndRemove(req.params.prospectId)
    .then(prospect => {
        if(!prospect) {
            return res.status(404).send({
                message: "prospect not found with id " + req.params.prospectId
            });
        }
        res.send({message: "prospect deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "prospect not found with id " + req.params.prospectId
            });                
        }
        return res.status(500).send({
            message: "Could not delete prospect with id " + req.params.prospectId
        });
    });
};
