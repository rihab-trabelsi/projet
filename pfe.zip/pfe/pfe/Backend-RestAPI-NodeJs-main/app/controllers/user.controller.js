const User = require('../models/user.model.js');

// Create and Save a new user
exports.create = (req, res) => {
    // Validate request
    if(!req.body.nom) {
        return res.status(400).send({
            message: "Le contenu utilisateur ne peut pas être vide"
        });
    }

    // Create a utilisateur
    const user = new User({
        nom: req.body.nom || "Untitled Utilisateur", 
        prenom : req.body.prenom ,
        adresse: req.body. adresse,
        email: req.body. email,
        telephone: req.body. telephone,
        mdp: req.body. mdp,
        role1: req.body. role1,
        date_integration: req.body.date_integration,
        image : req.body.image
        
    });

    // Save utilisateur in the database
    user.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la création de l'utilisateur."
        });
    });
};

// Retrieve and return all utilisateur from the database.
exports.findAll = (req, res) => {
    User.find()
    .then(users => {
        res.send(users);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la récupération des utilisateurs."
        });
    });
};

// Find a single utilisateur with a utilisateurId
exports.findOne = (req, res) => {
    User.findById(req.params.userId)
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "utilisateur introuvable avec id " + req.params.userId
            });            
        }
        res.send(user);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "utilisateur introuvable avec id " + req.params.userId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la récupération de l'utilisateur avec id " + req.params.userId
        });
    });
};

// Update a utilisateur identified by the utilisateurId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.nom) {
        return res.status(400).send({
            message: "Le contenu utilisateur ne peut pas être vide"
        });
    }

    // Find utilisateur and update it with the request body
    User.findByIdAndUpdate(req.params.userId, {
        nom: req.body.nom || "Untitled Utilisateur", 
        prenom : req.body.prenom ,
        adresse: req.body.adresse,
        email: req.body.email,
        telephone: req.body.telephone,
        mdp: req.body.mdp,
        role1: req.body.role1,
        date_integration: req.body.date_integration,
        image : req.body.image
    }, {new: true})
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "utilisateur introuvable avec id " + req.params.userId
            });
        }
        res.send(user);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "utilisateur introuvable avec id " + req.params.userId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la mise à jour de l'utilisateur avec id " + req.params.userId
        });
    });
};

// Delete a utilisateur with the specified utilisateurId in the request
exports.delete = (req, res) => {
    User.findByIdAndRemove(req.params.userId)
    .then(user => {
        if(!user) {
            return res.status(404).send({
                message: "utilisateur introuvable avec id " + req.params.userlId
            });
        }
        res.send({message: "utilisateur supprimer avec succée!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'introuvable') {
            return res.status(404).send({
                message: "utilisateur introuvable avec id " + req.params.userId
            });                
        }
        return res.status(500).send({
            message: "Impossible de supprimer l'utilisateur avec id " + req.params.userId
        });
    });
};
