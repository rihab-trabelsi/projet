const Tache = require('../models/tache.model.js');

// Create and Save a new tache
exports.create = (req, res) => {
    // Validate request
    if(!req.body.date) {
        return res.status(400).send({
            message: "tache content can not be empty"
        });
    }

    // Create a tache
    const tache = new Tache({
        titre: req.body.titre || "Untitled tache", 
        lieu : req.body.lieu, 
        dat: req.body.dat,
        desc : req.body.desc,
        responsable :req.body.responsable,
        etat :req.body.etat

    });

    // Save tache in the database
    tache.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the tache."
        });
    });
};

// Retrieve and return all tache from the database.
exports.findAll = (req, res) => {
    Tache.find()
    .then(taches => {
        res.send(taches);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving taches."
        });
    });
};

// Find a single tache with a tacheId
exports.findOne = (req, res) => {
    Tache.findById(req.params.tacheId)
    .then(tache => {
        if(!tache) {
            return res.status(404).send({
                message: "tache not found with id " + req.params.tacheId
            });            
        }
        res.send(tache);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "tache not found with id " + req.params.tacheId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving tache with id " + req.params.tacheId
        });
    });
};

// Update a tache identified by the tacheId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.date) {
        return res.status(400).send({
            message: "tache content can not be empty"
        });
    }

    // Find tache and update it with the request body
    Tache.findByIdAndUpdate(req.params.tacheId, {
        titre: req.body.titre || "Untitled tache", 
        lieu : req.body.lieu, 
        dat: req.body.dat,
        desc : req.body.desc,
        responsable :req.body.responsable,
        etat :req.body.etat

    }, {new: true})
    .then(tache => {
        if(!tache) {
            return res.status(404).send({
                message: "tache not found with id " + req.params.tacheId
            });
        }
        res.send(tache);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "tache not found with id " + req.params.tacheId
            });                
        }
        return res.status(500).send({
            message: "Error updating tache with id " + req.params.tacheId
        });
    });
};

// Delete a tache with the specified tacheId in the request
exports.delete = (req, res) => {
    Tache.findByIdAndRemove(req.params.tacheId)
    .then(tache => {
        if(!tache) {
            return res.status(404).send({
                message: "tache not found with id " + req.params.tacheId
            });
        }
        res.send({message: "tache deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "tache not found with id " + req.params.tacheId
            });                
        }
        return res.status(500).send({
            message: "Could not delete tache with id " + req.params.tacheId
        });
    });
};
