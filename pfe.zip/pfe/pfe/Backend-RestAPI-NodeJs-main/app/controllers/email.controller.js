const Email = require('../models/email.model.js');

// Create and Save a new email
exports.create = (req, res) => {
    // Validate request
    if(!req.body.date) {
        return res.status(400).send({
            email: "email content can not be empty"
        });
    }

    // Create a email
    const email = new Email({
        email_des: req.body.email_des || "Untitled email", 
        objet : req.body.objet,
        description: req.body.description
    });

    // Save email in the database
    email.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            email: err.email || "Some error occurred while creating the email."
        });
    });
};

// Retrieve and return all email from the database.
exports.findAll = (req, res) => {
    Email.find()
    .then(emails => {
        res.send(emails);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving messages."
        });
    });
};

// Find a single emails with a emailsId
exports.findOne = (req, res) => {
    Emails.findById(req.params.emailsId)
    .then(emails => {
        if(!emails) {
            return res.status(404).send({
                message: "message not found with id " + req.params.emailsId
            });            
        }
        res.send(email);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "message not found with id " + req.params.emailId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving tache with id " + req.params.emailId
        });
    });
};

