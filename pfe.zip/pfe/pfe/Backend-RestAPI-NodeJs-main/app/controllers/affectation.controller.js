const Affectation = require('../models/affectation.model.js');

// Create and Save a new affectation
exports.create = (req, res) => {
    // Validate request
    if(!req.body.nom_commercial) {
        return res.status(400).send({
            message: "Le contenu Affectation ne peut pas être vide"
        });
    }

    // Create a affectation
    const affectation = new Affectation({
        nom_commercial: req.body.nom_commercial || "Untitled Affectation", 
        nom_prospect : req.body.nom_prospect,
        date : req.body.date,
        desc : req.body.desc,
        lieu: req.body.lieu
    });

    // Save affectation in the database
    affectation.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la création de l'affectation."
        });
    });
};

// Retrieve and return all affectation from the database.
exports.findAll = (req, res) => {
    Affectation.find()
    .then(affectations => {
        res.send(affectations);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la récupération des affectations."
        });
    });
};

// Find a single affectation with a affectationId
exports.findOne = (req, res) => {
    Affectation.findById(req.params.affectationId)
    .then(affectation => {
        if(!affectation) {
            return res.status(404).send({
                message: "affectation introuvable avec id " + req.params.affectationId
            });            
        }
        res.send(affectation);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "affectation introuvable avec id " + req.params.affectationId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la récupération de l'affectation avec id " + req.params.affectationId
        });
    });
};

// Update a affectation identified by the affectationId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.nom_commercial) {
        return res.status(400).send({
            message: "Le contenu Affectation ne peut pas être vide"
        });
    }

    // Find affectation and update it with the request body
    Affectation.findByIdAndUpdate(req.params.affectationId, {
        nom_commercial: req.body.nom_commercial || "Untitled affectation", 
        nom_prospect : req.body.nom_prospect,
        date : req.body.date,
        desc : req.body.desc,
        lieu: req.body.lieu
    }, {new: true})
    .then(affectation => {
        if(!affectation) {
            return res.status(404).send({
                message: "affectation introuvable avec id " + req.params.affectationId
            });
        }
        res.send(affectation);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "affectation introuvable avec id " + req.params.affectationId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la mise à jour de l'affectation avec id " + req.params.affectationId
        });
    });
};

// Delete a affectation with the specified affectationId in the request
exports.delete = (req, res) => {
    Affectation.findByIdAndRemove(req.params.affectationId)
    .then(affectation => {
        if(!affectation) {
            return res.status(404).send({
                message: "affectation introuvable avec id " + req.params.affectationId
            });
        }
        res.send({message: "affectation supprimer avec succée!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'introuvable') {
            return res.status(404).send({
                message: "affectation introuvable avec id " + req.params.affectationId
            });                
        }
        return res.status(500).send({
            message: "Impossible de supprimer l'affectation avec id " + req.params.affectationId
        });
    });
};
