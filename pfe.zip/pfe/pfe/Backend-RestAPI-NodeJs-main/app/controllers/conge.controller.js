const Conge = require('../models/conge.model.js');

// Create and Save a new conge
exports.create = (req, res) => {
    // Validate request
    if(!req.body.date) {
        return res.status(400).send({
            message: "Le contenu conge ne peut pas être vide"
        });
    }

    // Create a conge
    const conge = new Conge({
        date_debut: req.body.date_debut || "Untitled conge", 
        date_fin : req.body.date_fin, 
        type: req.body.type,
        nombre_jour : req.body.nombre_jour
    });

    // Save conge in the database
    conge.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la création de conge."
        });
    });
};

// Retrieve and return all conge from the database.
exports.findAll = (req, res) => {
    Conge.find()
    .then(conges => {
        res.send(conges);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la récupération des conges."
        });
    });
};

// Find a single conge with a congeId
exports.findOne = (req, res) => {
    Conge.findById(req.params.congeId)
    .then(conge => {
        if(!conge) {
            return res.status(404).send({
                message: "conge introuvable avec id " + req.params.congeId
            });            
        }
        res.send(conge);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "conge introuvable avec id " + req.params.congeId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la récupération de conge avec id " + req.params.congeId
        });
    });
};



// Retirer a conge with the specified congeId in the request
exports.delete = (req, res) => {
    Conge.findByIdAndRemove(req.params.congeId)
    .then(conge => {
        if(!conge) {
            return res.status(404).send({
                message: "conge introuvable avec id " + req.params.congeId
            });
        }
        res.send({message: "conge supprimer avec succée!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "conge introuvable avec id " + req.params.congeId
            });                
        }
        return res.status(500).send({
            message: "Impossible de supprimer conge avec id " + req.params.congeId
        });
    });
};
