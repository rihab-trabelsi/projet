const mongoose = require('mongoose');

const TacheSchema = mongoose.Schema({

        nom: String, 
        nom_contact : String, 
        email : String,
        date: String,   
        ville :String , 
        volume_annuel : String,
        heure_arrive :String,
        type_client :String,
        nature_client :String,
        decrir : String,
        autre: String,
        cause :String,
        resultat :String,
        commande :String,
        frs :String,
        prix :String,
        remarque :String,

}, {
    timestamps: true
});

module.exports = mongoose.model('Prospect', ProspectSchema);