const mongoose = require('mongoose');

const CongeSchema = mongoose.Schema({

    date_debut: String,
    date_fin :String ,
    type: String,
    nombre_jour : String
}, {
    timestamps: true
});

module.exports = mongoose.model('Conge', CongeSchema);