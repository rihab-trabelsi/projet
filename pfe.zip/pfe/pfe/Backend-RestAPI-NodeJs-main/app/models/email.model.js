const mongoose = require('mongoose');

const EmailSchema = mongoose.Schema({
    email_des: String,
    objet: String,
    description: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Email', EmailSchema);