const mongoose = require('mongoose');

const UserSchema = mongoose.Schema({
    nom: String,
    prenom: String,    
    adresse: String,
    email: {
            type: String,
            unique: [true, 'Email est unique']
           
    },
    telephone: String,    
    mdp: { 
        type: String,
        unique: [true, 'Mot de passe est unique']

    },

    role1: String,
    date_integration: String,
    image : String 
}, 
{
    timestamps: true
});

module.exports = mongoose.model('User', UserSchema);