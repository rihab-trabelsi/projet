const mongoose = require('mongoose');

const TacheSchema = mongoose.Schema({

    titre: String,
    lieu :String ,
    dat: String,
    desc : String,
    responsable : String,
    etat: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Tache', TacheSchema);