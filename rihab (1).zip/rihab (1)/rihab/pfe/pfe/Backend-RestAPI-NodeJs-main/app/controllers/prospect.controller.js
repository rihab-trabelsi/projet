const Prospect = require('../models/prospect.model.js');

// Create and Save a new prospect
exports.create = (req, res) => {
    // Validate request
    if(!req.body.date) {
        return res.status(400).send({
            message: "Le contenu prospect ne peut pas être vide"
        });
    }

    // Create a prospect
    const prospect = new Prospect({
        nom_prospect: req.body.nom_prospect || "Untitled prospect", 
        nom_contact : req.body.nom_contact, 
        email : req.body.email,
        telephone: req.body.telephone,
        date: req.body.date,   
        ville : req.body.ville, 
        volume_annuel : req.body.volume_annuel,
        heure_arrive :req.body.heure,
        type_client :req.body.type_client,
        nature_client :req.body.nature_client,
        cause :req.body.cause,
        resultat :req.body.resultat,
        commande :req.body.commande,
        frs :req.body.frs,
        prix1 :req.body.prix1,  
        prix2 :req.body.prix2,
        remarque :req.body.remarque,
        image : req.body.image,
        longitude : req.body.longitude,
        latitude : req.body.latitude

    });

    // Save prospect in the database
    prospect.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la création de prospect."
        });
    });
};

// Retrieve and return all prospect from the database.
exports.findAll = (req, res) => {
    Prospect.find()
    .then(prospects => {
        res.send(prospects);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Une erreur s'est produite lors de la récupération des prospects."
        });
    });
};

// Find a single prospect with a prospectId
exports.findOne = (req, res) => {
    Prospect.findById(req.params.prospectId)
    .then(prospect => {
        if(!prospect) {
            return res.status(404).send({
                message: "prospect introuvable avec id " + req.params.prospectId
            });            
        }
        res.send(prospect);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "prospect introuvable avec id " + req.params.prospectId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la récupération de prospect avec id" + req.params.prospectId
        });
    });
};

// Update a prospect identified by the prospectId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.date) {
        return res.status(400).send({
            message: "prospect content can not be empty"
        });
    }

    // Find prospect and update it with the request body
    Prospect.findByIdAndUpdate(req.params.prospectId, {
        nom_prospect: req.body.nom_prospect || "Untitled prospect", 
        nom_contact : req.body.nom_contact, 
        email: req.body.email,
        telephone: req.body.telephone,
        date : req.body.date,
        ville :req.body.ville,
        volume_annuel :req.body.volume_annuel,
        heure_arrive :req.body.heure_arrive,
        type_client :req.body.type_client,
        nature_client :req.body.nature_client,
        cause :req.body.cause,
        resultat :req.body.resultat,
        commande :req.body.commande,
        frs :req.body.frs,
        prix1 :req.body.prix1,  
        prix2 :req.body.prix2, 
        remarque :req.body.remarque,
        image : req.body.image,
        longitude : req.body.longitude,
        latitude : req.body.latitude

    }, {new: true})
    .then(prospect => {
        if(!prospect) {
            return res.status(404).send({
                message: "prospect introuvable avec id " + req.params.prospectId
            });
        }
        res.send(prospect);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "prospect introuvable avec id " + req.params.prospectId
            });                
        }
        return res.status(500).send({
            message: "Erreur lors de la mise à jour de prospect avec id  " + req.params.prospectId
        });
    });
};

// Delete a prospect with the specified adminId in the request
exports.delete = (req, res) => {
    Prospect.findByIdAndRemove(req.params.prospectId)
    .then(prospect => {
        if(!prospect) {
            return res.status(404).send({
                message: "prospect introuvable avec id " + req.params.prospectId
            });
        }
        res.send({message: "prospect supprimer avec succée!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "prospect introuvable avec id " + req.params.prospectId
            });                
        }
        return res.status(500).send({
            message: "Impossible de supprimer prospect avec id" + req.params.prospectId
        });
    });
};
