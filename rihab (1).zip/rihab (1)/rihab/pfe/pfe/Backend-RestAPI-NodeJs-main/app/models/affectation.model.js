const mongoose = require('mongoose');

const AffectationSchema = mongoose.Schema({
    nom_commercial: String,
    nom_commercial1: String,
    nom_prospect: String,
    date: String,
    desc: String,       
    lieu: String
},
 {
    timestamps: true
});

module.exports = mongoose.model('Affectation', AffectationSchema);