const mongoose = require('mongoose');

const TacheSchema = mongoose.Schema({

    titre: {
        type: String,
        unique: [true, 'Titre tache est unique']
       
    },    
    lieu :String ,
    date: String,
    desc : String,
    responsable : String,
    etat1: String,
    etat2: String

}, {
    timestamps: true
});

module.exports = mongoose.model('Tache', TacheSchema);