const mongoose = require('mongoose');

const ProspectSchema = mongoose.Schema({

        nom_prospect: String, 
        nom_contact : String, 
        email : String,
        telephone: String,
        date: String,   
        ville :String , 
        volume_annuel : String,
        heure_arrive :String,
        type_client :String,
        nature_client :String,
        cause :String,
        resultat :String,
        commande :String,
        frs :String,
        prix1 :String,
        prix2 :String,
        remarque :String,
        image : String,
        longitude: String,
        latitude: String


}, {
    timestamps: true
});

module.exports = mongoose.model('Prospect', ProspectSchema);